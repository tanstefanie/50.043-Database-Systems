ISTD 50043 Group Project
===========

Welcome!

## Labs
Your project consists of four labs. You are *strongly advised* to start early.  

* [Lab 1](lab1.md): due **3/3 11.59pm**.
* [Lab 2](lab2.md): due **17/3 11.59pm**.
* [Lab 3](lab3.md): due **7/4 11.59pm**. 
* [Lab 4](lab4.md): due **21/4 11.59pm**. 

Each lab is given **15 points**: **12** for passing all the tests, and **3** for the report. 

## Important
In addition to the academic integrity policy (as discussed in the lecture), take note that: 
* You cannot make your Github repository for the labs public. 
* You cannot copy and paste code from other people or any other sources. 
* You cannot share your solutions.  


### Acknowledgement
The labs are modified from the MIT 6830 course. We thank the MIT staff for the materials.  
