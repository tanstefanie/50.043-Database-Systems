import sys
from pyspark.sql import SparkSession

# you may add more import if you need to
from pyspark.sql.functions import col, explode, split


# don't change this line
hdfs_nn = sys.argv[1]

spark = SparkSession.builder.appName("Assigment 2 Question 4").getOrCreate()
# YOUR CODE GOES BELOW

## Question 4: Count the number of restaurants by city and cuisine style

# Load data
df = spark.read.option("header", "true").csv("/student_files/data/TA_restaurants_curated_cleaned.csv")

# Split and explode cuisine styles
exploded_df = df.withColumn("Cuisine", explode(split(col("Cuisine Style"), ",")))

# Count restaurants
count_df = exploded_df.groupBy("City", "Cuisine").count()

# Write output
count_df.write.option("header", "true").csv("/student_files/output/question4/")