import sys
from pyspark.sql import SparkSession

# you may add more import if you need to
from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number

# don't change this line
hdfs_nn = sys.argv[1]

spark = SparkSession.builder.appName("Assigment 2 Question 2").getOrCreate()
# YOUR CODE GOES BELOW
 
## Question 2: Find the best and worst restaurants for each city and price range

# Load data
df = spark.read.option("header", "true").csv("/student_files/data/TA_restaurants_curated_cleaned.csv")

# Define window specs
window_spec = Window.partitionBy("City", "Price Range").orderBy(col("Rating").desc())
window_spec_asc = Window.partitionBy("City", "Price Range").orderBy(col("Rating").asc())

# Rank restaurants
ranked_df = df.withColumn("rank_desc", row_number().over(window_spec)) \
              .withColumn("rank_asc", row_number().over(window_spec_asc))

# Filter best and worst
best_worst_df = ranked_df.filter((col("rank_desc") == 1) | (col("rank_asc") == 1))

# Write output
best_worst_df.write.option("header", "true").csv("/student_files/output/question2/")