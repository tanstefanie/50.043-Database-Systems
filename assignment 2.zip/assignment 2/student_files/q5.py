import sys 
from pyspark.sql import SparkSession
# you may add more import if you need to
from pyspark.sql.functions import col, explode, array_sort, collect_list
from pyspark.sql.types import ArrayType, StringType
import json

# don't change this line
hdfs_nn = sys.argv[1]

spark = SparkSession.builder.appName("Assigment 2 Question 5").getOrCreate()
# YOUR CODE GOES BELOW

## Question 5: Find pairs of actors/actresses that are co-cast in at least 2 movies

# Define the schema for the cast entries
schema = ArrayType(StructType([
    StructField("cast_id", IntegerType(), True),
    StructField("character", StringType(), True),
    StructField("credit_id", StringType(), True),
    StructField("gender", IntegerType(), True),
    StructField("id", IntegerType(), True),
    StructField("name", StringType(), True),
    StructField("order", IntegerType(), True)
]))

# Read the Parquet file
df = spark.read.parquet("/student_files/data/tmdb_5000_credits.parquet")

# Deserialize JSON in the cast column to array of struct using the defined schema
df = df.withColumn("cast", from_json("cast", schema))

# Explode the cast column to get individual actors
df = df.withColumn("cast", explode("cast"))

# Extract actor names and create pairs within each movie
df = df.select(
    "movie_id",
    "title",
    col("cast.cast_id").alias("actor_id"),
    col("cast.name").alias("actor_name")
)

# Self join on movie_id to find pairs of actors in the same movie
df_pairs = df.alias("df1").join(df.alias("df2"), "movie_id") \
    .where("df1.actor_id < df2.actor_id") \
    .select(
        col("df1.movie_id"),
        col("df1.title"),
        col("df1.actor_name").alias("actor1_name"),
        col("df2.actor_name").alias("actor2_name")
    )

# Group by pairs and count appearances across different movies
df_pairs = df_pairs.groupBy("actor1_name", "actor2_name") \
    .agg(
        collect_list(col("movie_id")).alias("movies"), 
        collect_list(col("title")).alias("titles")
    ) \
    .where("size(movies) > 1")

# Save to Parquet
df_pairs.write.parquet("/student_files/output/question5/")

# Stop Spark session
spark.stop()
