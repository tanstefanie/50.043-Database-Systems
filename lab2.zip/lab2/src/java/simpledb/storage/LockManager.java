package simpledb.storage;

public class LockManager {

}
