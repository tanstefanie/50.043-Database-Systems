package simpledb.storage;

import simpledb.common.Database;
import simpledb.common.Permissions;
import simpledb.common.DbException;
import simpledb.common.DeadlockException;
import simpledb.transaction.TransactionAbortedException;
import simpledb.transaction.TransactionId;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

/**
 * BufferPool manages the reading and writing of pages into memory from
 * disk. Access methods call into it to retrieve pages, and it fetches
 * pages from the appropriate location.
 * <p>
 * The BufferPool is also responsible for locking; when a transaction fetches
 * a page, BufferPool checks that the transaction has the appropriate
 * locks to read/write the page.
 * 
 * @Threadsafe, all fields are final
 */
public class BufferPool {
    /** Bytes per page, including header. */
    private static final int DEFAULT_PAGE_SIZE = 4096;

    private static int pageSize = DEFAULT_PAGE_SIZE;

    /**
     * Default number of pages passed to the constructor. This is used by
     * other classes. BufferPool should use the numPages argument to the
     * constructor instead.
     */
    public static final int DEFAULT_PAGES = 50;

    private final int maxPages;
    private final ConcurrentHashMap<PageId, Integer> pageAge;
    private final ConcurrentHashMap<PageId, Page> pages;
    private int age;
    private LockManager lockManager;

    private class LockManager {
        private final Map<PageId, Set<TransactionId>> sharedLocks = new HashMap<>();
        private final Map<PageId, TransactionId> exclusiveLocks = new HashMap<>();

        private Map<TransactionId, Set<TransactionId>> waitForGraph = new HashMap<>();

        public synchronized boolean acquireLock(PageId pid, TransactionId tid, Permissions perm) throws TransactionAbortedException {
            try {
                while (!canAcquireLock(pid, tid, perm)) {
                    Set<TransactionId> currentLockHolders = getLockHolders(pid);
        
                    for (TransactionId holder : currentLockHolders) {
                        addToWaitForGraph(tid, holder);
                    }
        
                    if (checkForCycle(tid)) {
                        for (TransactionId holder : currentLockHolders) {
                            removeFromWaitForGraph(tid, holder);
                        }
                        throw new TransactionAbortedException();
                        // return false;
                    }
        
                    wait();
        
                    for (TransactionId holder : currentLockHolders) {
                        removeFromWaitForGraph(tid, holder);
                    }
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt(); 
                return false;
            }
        
            if (perm.equals(Permissions.READ_ONLY)) {
                sharedLocks.computeIfAbsent(pid, k -> new HashSet<>()).add(tid);
            } else { 
                exclusiveLocks.put(pid, tid);
            }
        
            return true; 
        }
        
        private Set<TransactionId> getLockHolders(PageId pid) {
            Set<TransactionId> holders = new HashSet<>();
            TransactionId exclusiveHolder = exclusiveLocks.get(pid);
            if (exclusiveHolder != null) {
                holders.add(exclusiveHolder);
            }
            Set<TransactionId> sharedHolders = sharedLocks.get(pid);
            if (sharedHolders != null) {
                holders.addAll(sharedHolders);
            }
            return holders;
        }

        private void addToWaitForGraph(TransactionId waiter, TransactionId holder) {
            waitForGraph.computeIfAbsent(waiter, k -> new HashSet<>()).add(holder);
        }

        private void removeFromWaitForGraph(TransactionId waiter, TransactionId holder) {
            if (waitForGraph.containsKey(waiter)) {
                waitForGraph.get(waiter).remove(holder);
                if (waitForGraph.get(waiter).isEmpty()) {
                    waitForGraph.remove(waiter); 
                }
            }
        }

        private boolean checkForCycle(TransactionId start) {
            Set<TransactionId> visited = new HashSet<>();
            return isCyclicUtil(start, visited, new HashSet<>());
        }
        
        private boolean isCyclicUtil(TransactionId current, Set<TransactionId> visited, Set<TransactionId> recStack) {
            if (recStack.contains(current)) {
                return true;
            }
            if (visited.contains(current)) {
                return false;
            }
            visited.add(current);
            recStack.add(current);
            Set<TransactionId> children = waitForGraph.getOrDefault(current, Collections.emptySet());
            for (TransactionId child : children) {
                if (isCyclicUtil(child, visited, recStack)) {
                    return true;
                }
            }
            recStack.remove(current);
            return false;
        }
        
        
        private boolean canAcquireLock(PageId pid, TransactionId tid, Permissions perm) {
            if (exclusiveLocks.containsKey(pid) && !exclusiveLocks.get(pid).equals(tid)) {
                return false; 
            }
            if (perm.equals(Permissions.READ_WRITE) && sharedLocks.containsKey(pid)) {
                return sharedLocks.get(pid).size() == 1 && sharedLocks.get(pid).contains(tid); 
            }
            return true;
        }

        public synchronized void releaseLock(PageId pid, TransactionId tid) {
            sharedLocks.getOrDefault(pid, Collections.emptySet()).remove(tid);
            if (sharedLocks.get(pid) != null && sharedLocks.get(pid).isEmpty()) {
                sharedLocks.remove(pid);
            }
            if (tid.equals(exclusiveLocks.get(pid))) {
                exclusiveLocks.remove(pid);
            }
            notifyAll(); 
        }

        public synchronized void releaseAllLocks(TransactionId tid) {
            Iterator<Map.Entry<PageId, TransactionId>> exclusiveIter = exclusiveLocks.entrySet().iterator();
            while (exclusiveIter.hasNext()) {
                Map.Entry<PageId, TransactionId> entry = exclusiveIter.next();
                if (entry.getValue().equals(tid)) {
                    exclusiveIter.remove();
                }
            }
        
            Iterator<Map.Entry<PageId, Set<TransactionId>>> sharedIter = sharedLocks.entrySet().iterator();
            while (sharedIter.hasNext()) {
                Map.Entry<PageId, Set<TransactionId>> entry = sharedIter.next();
                entry.getValue().remove(tid);
                if (entry.getValue().isEmpty()) {
                    sharedIter.remove();
                }
            }
        
            notifyAll(); 
        }

        public void handleTransactionAbort(TransactionId tid){
            lockManager.releaseAllLocks(tid);
        }

        public synchronized boolean holdsLock(PageId pid, TransactionId tid) {
            return sharedLocks.getOrDefault(pid, Collections.emptySet()).contains(tid)
                    || tid.equals(exclusiveLocks.get(pid));
        }
    }

    /**
     * Creates a BufferPool that caches up to numPages pages.
     *
     * @param numPages maximum number of pages in this buffer pool.
     */
    public BufferPool(int numPages) {
        this.maxPages = numPages;
        this.pages = new ConcurrentHashMap<PageId, Page>();
        this.pageAge = new ConcurrentHashMap<PageId, Integer>();
        this.age = 0;
        this.lockManager = new LockManager();
    }

    public static int getPageSize() {
        return pageSize;
    }

    // THIS FUNCTION SHOULD ONLY BE USED FOR TESTING!!
    public static void setPageSize(int pageSize) {
        BufferPool.pageSize = pageSize;
    }

    // THIS FUNCTION SHOULD ONLY BE USED FOR TESTING!!
    public static void resetPageSize() {
        BufferPool.pageSize = DEFAULT_PAGE_SIZE;
    }

    /**
     * Retrieve the specified page with the associated permissions.
     * Will acquire a lock and may block if that lock is held by another
     * transaction.
     * <p>
     * The retrieved page should be looked up in the buffer pool. If it
     * is present, it should be returned. If it is not present, it should
     * be added to the buffer pool and returned. If there is insufficient
     * space in the buffer pool, a page should be evicted and the new page
     * should be added in its place.
     *
     * @param tid  the ID of the transaction requesting the page
     * @param pid  the ID of the requested page
     * @param perm the requested permissions on the page
     */
    public Page getPage(TransactionId tid, PageId pid, Permissions perm)
            throws TransactionAbortedException, DbException {
        try{
            if (!lockManager.acquireLock(pid, tid, perm)) {
            throw new TransactionAbortedException();
            }
        }catch (TransactionAbortedException e){
            lockManager.handleTransactionAbort(tid);
            throw e;
        }

        if (!pages.containsKey(pid)) {
            int tableId = pid.getTableId();
            DbFile file = Database.getCatalog().getDatabaseFile(tableId);
            Page page = file.readPage(pid);

            if (pages.size() == maxPages) {
                evictPage();
            }
            pages.put(pid, page);
            pageAge.put(pid, age++);
            return page;
        }
        return pages.get(pid);
    }

    /**
     * Releases the lock on a page.
     * Calling this is very risky, and may result in wrong behavior. Think hard
     * about who needs to call this and why, and why they can run the risk of
     * calling it.
     *
     * @param tid the ID of the transaction requesting the unlock
     * @param pid the ID of the page to unlock
     */
    public void unsafeReleasePage(TransactionId tid, PageId pid) {
        lockManager.releaseLock(pid, tid);
    }

    /**
     * Release all locks associated with a given transaction.
     *
     * @param tid the ID of the transaction requesting the unlock
     * @throws IOException
     */
    public void transactionComplete(TransactionId tid) throws IOException {
        transactionComplete(tid, true);
    }

    /** Return true if the specified transaction has a lock on the specified page */
    public boolean holdsLock(TransactionId tid, PageId p) {
        return lockManager.holdsLock(p, tid);
    }

    /**
     * Commit or abort a given transaction; release all locks associated to
     * the transaction.
     *
     * @param tid the ID of the transaction requesting the unlock
     * @param commit a flag indicating whether we should commit or abort
     * @throws IOException
     */
    public void transactionComplete(TransactionId tid, boolean commit) throws IOException {
        if (commit) {
            flushPages(tid);
        } else {
            restorePages(tid);
        }

        for (PageId pid : pages.keySet()) {
            if (holdsLock(tid, pid)) {
                unsafeReleasePage(tid, pid);
            }
        }
    }

    private synchronized void restorePages(TransactionId transactionId) {
        for (PageId pid : pages.keySet()) {
            Page page = pages.get(pid);

            if (page.isDirty() == transactionId) {
                int tableId = pid.getTableId();
                DbFile file = Database.getCatalog().getDatabaseFile(tableId);
                Page pageDisk = file.readPage(pid);

                pages.put(pid, pageDisk);
            }
        }
    }

    /**
     * Add a tuple to the specified table on behalf of transaction tid. Will
     * acquire a write lock on the page the tuple is added to and any other
     * pages that are updated (Lock acquisition is not needed for lab2).
     * May block if the lock(s) cannot be acquired.
     * 
     * Marks any pages that were dirtied by the operation as dirty by calling
     * their markDirty bit, and adds versions of any pages that have
     * been dirtied to the cache (replacing any existing versions of those pages) so
     * that future requests see up-to-date pages.
     *
     * @param tid     the transaction adding the tuple
     * @param tableId the table to add the tuple to
     * @param t       the tuple to add
     */
    public void insertTuple(TransactionId tid, int tableId, Tuple t)
            throws DbException, IOException, TransactionAbortedException {
        DbFile file = Database.getCatalog().getDatabaseFile(tableId);
        List<Page> dirtiedPages = file.insertTuple(tid, t);
        updateBufferPool(dirtiedPages, tid);
    }

    /**
     * Remove the specified tuple from the buffer pool.
     * Will acquire a write lock on the page the tuple is removed from and any
     * other pages that are updated. May block if the lock(s) cannot be acquired.
     *
     * Marks any pages that were dirtied by the operation as dirty by calling
     * their markDirty bit, and adds versions of any pages that have
     * been dirtied to the cache (replacing any existing versions of those pages) so
     * that future requests see up-to-date pages.
     *
     * @param tid the transaction deleting the tuple.
     * @param t the tuple to delete
     */
    public void deleteTuple(TransactionId tid, Tuple t)
            throws DbException, IOException, TransactionAbortedException {
        DbFile file = Database.getCatalog().getDatabaseFile(t.getRecordId().getPageId().getTableId());
        List<Page> dirtiedPages = file.deleteTuple(tid, t);
        updateBufferPool(dirtiedPages, tid);
    }

    private void updateBufferPool(List<Page> dirtiedPages, TransactionId tid) throws DbException {
        for (Page page : dirtiedPages) {
            page.markDirty(true, tid);
            PageId pid = page.getId();

            if (pages.containsKey(pid)) {
                pages.replace(pid, page);
            } else {
                if (pages.size() >= maxPages) {
                    evictPage();
                }
                pages.put(pid, page);
            }
        }
    }

    /**
     * Flush all dirty pages to disk.
     * NB: Be careful using this routine -- it writes dirty data to disk so will
     * break simpledb if running in NO STEAL mode.
     */
    public synchronized void flushAllPages() throws IOException {
        for (Page p : pages.values()) {
            flushPage((p.getId()));
        }
    }

    /**
     * Remove the specific page id from the buffer pool.
     * Needed by the recovery manager to ensure that the
     * buffer pool doesn't keep a rolled back page in its
     * cache.
     * 
     * Also used by B+ tree files to ensure that deleted pages
     * are removed from the cache so they can be reused safely
     */
    public synchronized void discardPage(PageId pid) {
        pages.remove(pid);
    }

    /**
     * Flushes a certain page to disk
     * 
     * @param pid an ID indicating the page to flush
     */
    private synchronized void flushPage(PageId pid) throws IOException {
        Page pg = pages.get(pid);
        if (pg == null) {
            throw new IOException("Attempted to flush a page that is not present in the buffer pool.");
        }

        TransactionId tid = pg.isDirty();
        if (tid != null) {
            Database.getLogFile().logWrite(tid, pg.getBeforeImage(), pg);
            Database.getLogFile().force();
            Database.getCatalog().getDatabaseFile(pid.getTableId()).writePage(pg);
            pg.markDirty(false, null);
        }
    }

    /**
     * Write all pages of the specified transaction to disk.
     */
    public synchronized void flushPages(TransactionId tid) throws IOException {
        for (PageId pid: pages.keySet()) {
            Page page = pages.get(pid);
            if (page.isDirty() == tid) {
                flushPage(pid);
            }
        }
    }

    /**
     * Discards a page from the buffer pool.
     * Flushes the page to disk to ensure dirty pages are updated on disk.
     */
    private synchronized void evictPage() throws DbException {
        // some code goes here
        // not necessary for lab1
        // eviction policy implemented is Clock Replacement Policy

        boolean evicted = false;

        PageId pageId = null;
        int oldestAge = -1;

        for (PageId pid: pageAge.keySet()) {
            Page selectedPage = pages.get(pid);

            if (selectedPage.isDirty() != null) {
                continue;
            }

            if (pageId == null) {
                pageId = pid;
                oldestAge = pageAge.get(pid);
                evicted = true;
                continue;
            }

            if (pageAge.get(pid) < oldestAge) {
                pageId = pid;
                oldestAge = pageAge.get(pid);
            }
        }

        if (!evicted) {
            throw new DbException("No suitable page found to evict.");
        }

        pages.remove(pageId);
        pageAge.remove(pageId);
    }
}