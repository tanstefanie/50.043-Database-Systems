package simpledb.storage;

import simpledb.common.Database;
import simpledb.common.DbException;
import simpledb.common.Permissions;
import simpledb.transaction.TransactionAbortedException;
import simpledb.transaction.TransactionId;

import java.io.*;
import java.util.*;

/**
 * HeapFile is an implementation of a DbFile that stores a collection of tuples
 * in no particular order. Tuples are stored on pages, each of which is a fixed
 * size, and the file is simply a collection of those pages. HeapFile works
 * closely with HeapPage. The format of HeapPages is described in the HeapPage
 * constructor.
 * 
 * @see HeapPage#HeapPage
 * @author Sam Madden
 */
public class HeapFile implements DbFile {

    private final File file;
    private final TupleDesc tupleDesc;

    /**
     * Constructs a heap file backed by the specified file.
     * 
     * @param f
     *          the file that stores the on-disk backing store for this heap
     *          file.
     */
    public HeapFile(File f, TupleDesc td) {
        this.file = f;
        this.tupleDesc = td;
    }

    /**
     * Returns the File backing this HeapFile on disk.
     * 
     * @return the File backing this HeapFile on disk.
     */
    public File getFile() {
        return file;
    }

    /**
     * Returns an ID uniquely identifying this HeapFile. Implementation note:
     * you will need to generate this tableid somewhere to ensure that each
     * HeapFile has a "unique id," and that you always return the same value for
     * a particular HeapFile. We suggest hashing the absolute file name of the
     * file underlying the heapfile, i.e. f.getAbsoluteFile().hashCode().
     * 
     * @return an ID uniquely identifying this HeapFile.
     */
    public int getId() {
        return file.getAbsoluteFile().hashCode();
    }

    /**
     * Returns the TupleDesc of the table stored in this DbFile.
     * 
     * @return TupleDesc of this DbFile.
     */
    public TupleDesc getTupleDesc() {
        return tupleDesc;
    }

    // see DbFile.java for javadocs
    public Page readPage(PageId pid) {
        int pageNum = pid.getPageNumber();
        int tableId = pid.getTableId();

        RandomAccessFile f = null;

        try {
            f = new RandomAccessFile(file, "r");
            if ((pageNum + 1) * BufferPool.getPageSize() > f.length()) {
                throw new IllegalArgumentException(
                        String.format("Table %d with page number %d is out of range", tableId, pageNum));
            }

            byte[] bytes = new byte[BufferPool.getPageSize()];
            f.seek(pageNum * BufferPool.getPageSize());
            int read = f.read(bytes, 0, BufferPool.getPageSize());

            if (read != BufferPool.getPageSize()) {
                throw new IllegalArgumentException(String.format(
                        "There is unexpected error when accessing file with table id %d page number %d with %d byte(s)",
                        tableId, pageNum, read));
            }

            HeapPageId heapPageId = new HeapPageId(pid.getTableId(), pid.getPageNumber());
            return new HeapPage(heapPageId, bytes);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                f.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        throw new IllegalArgumentException(
                String.format("Table %d with page number %d is out of range", tableId, pageNum));
    }

    // see DbFile.java for javadocs
    public void writePage(Page page) throws IOException {
        int pageNumber = page.getId().getPageNumber();
        RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rw");

        randomAccessFile.seek(pageNumber * BufferPool.getPageSize());
        randomAccessFile.write(page.getPageData());
        randomAccessFile.close();
    }

    /**
     * Returns the number of pages in this HeapFile.
     */
    public int numPages() {
        int num = (int) Math.ceil(file.length() / BufferPool.getPageSize());
        return num;
    }

    // see DbFile.java for javadocs
    public List<Page> insertTuple(TransactionId tid, Tuple t)
            throws DbException, IOException, TransactionAbortedException {

        HeapPage page = null;

        // find a non full page
        for (int i = 0; i < numPages(); ++i) {
            HeapPageId pid = new HeapPageId(getId(), i);
            page = (HeapPage) Database.getBufferPool().getPage(tid, pid, Permissions.READ_WRITE);
            if (page.getNumEmptySlots() != 0) {
                break;
            } else {
                Database.getBufferPool().unsafeReleasePage(tid, pid);
            }
        }

        if (page == null || page.getNumEmptySlots() == 0) {
            HeapPageId pid = new HeapPageId(getId(), numPages());
            byte[] data = HeapPage.createEmptyPageData();
            HeapPage heapPage = new HeapPage(pid, data);
            writePage(heapPage);
            page = (HeapPage) Database.getBufferPool().getPage(tid, pid, Permissions.READ_WRITE);
        }

        page.insertTuple(t);

        ArrayList<Page> res = new ArrayList<>();
        res.add(page);
        return res;
    }

    // see DbFile.java for javadocs
    public ArrayList<Page> deleteTuple(TransactionId tid, Tuple t)
            throws DbException, TransactionAbortedException {

        RecordId rid = t.getRecordId();
        PageId pid = rid.getPageId();

        HeapPage page = (HeapPage) Database.getBufferPool().getPage(tid, pid, Permissions.READ_WRITE);
        page.deleteTuple(t);

        ArrayList<Page> res = new ArrayList<>();
        res.add(page);
        return res;

    }

    // see DbFile.java for javadocs
    public DbFileIterator iterator(TransactionId tid) {
        return new HeapFileIterator(this, tid);
    }

    private static final class HeapFileIterator implements DbFileIterator {
        private final HeapFile heapFile;
        private final TransactionId tid;
        private Iterator<Tuple> iterator;
        private int page;

        public HeapFileIterator(HeapFile file, TransactionId tid) {
            this.heapFile = file;
            this.tid = tid;
        }

        @Override
        public void open() throws DbException, TransactionAbortedException {
            page = 0;
            iterator = getPageTuples(page);
        }

        private Iterator<Tuple> getPageTuples(int pageNum) throws DbException, TransactionAbortedException {
            if (pageNum >= 0 && pageNum < heapFile.numPages()) {
                HeapPageId pid = new HeapPageId(heapFile.getId(), pageNum);
                HeapPage page = (HeapPage) Database.getBufferPool().getPage(tid, pid, Permissions.READ_ONLY);
                return page.iterator();
            } else {
                throw new DbException(
                        String.format("heapfile %d with page number %d is not valid", heapFile.getId(), pageNum));
            }
        }

        @Override
        public boolean hasNext() throws DbException, TransactionAbortedException {
            if (iterator == null) {
                return false;
            }

            while (!iterator.hasNext() && page < heapFile.numPages() - 1) {
                page++;
                iterator = getPageTuples(page);
            }
            return iterator.hasNext();
        }

        @Override
        public Tuple next() throws DbException, TransactionAbortedException, NoSuchElementException {
            if (iterator == null || !iterator.hasNext()) {
                throw new NoSuchElementException();
            }
            return iterator.next();
        }

        @Override
        public void rewind() throws DbException, TransactionAbortedException {
            close();
            open();
        }

        @Override
        public void close() {
            iterator = null;
        }
    }
}
