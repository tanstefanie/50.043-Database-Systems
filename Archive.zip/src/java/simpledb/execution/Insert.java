package simpledb.execution;

import java.io.IOException;

import simpledb.common.Database;
import simpledb.common.DbException;
import simpledb.common.Type;
import simpledb.storage.BufferPool;
import simpledb.storage.IntField;
import simpledb.storage.Tuple;
import simpledb.storage.TupleDesc;
import simpledb.transaction.TransactionAbortedException;
import simpledb.transaction.TransactionId;

/**
 * Inserts tuples read from the child operator into the tableId specified in the
 * constructor
 */
public class Insert extends Operator {

    private static final long serialVersionUID = 1L;

    private TransactionId tid;
    private final TupleDesc tupledesc;
    private OpIterator child;
    private int tableId;

    private int count;
    private boolean isCalled;

    /**
     * Constructor.
     *
     * @param t
     *            The transaction running the insert.
     * @param child
     *            The child operator from which to read tuples to be inserted.
     * @param tableId
     *            The table in which to insert tuples.
     * @throws DbException
     *             if TupleDesc of child differs from table into which we are to
     *             insert.
     */
    public Insert(TransactionId t, OpIterator child, int tableId)
            throws DbException {
        // some code goes here
        if(!child.getTupleDesc().equals(Database.getCatalog().getTupleDesc(tableId))){
            throw new DbException("Tuple doesn't match!");
        }
        this.tid = t;
        this.child = child;
        this.tableId = tableId;
        this.tupledesc = new TupleDesc(new Type[]{Type.INT_TYPE}, new String[]{"the number of tuples inserted"});
        this.count = -1;
        this.isCalled = false;
    }

    public TupleDesc getTupleDesc() {
        // some code goes here
        return this.tupledesc;
    }

    public void open() throws DbException, TransactionAbortedException {
        // some code goes here
        this.count = 0;
        this.child.open();
        super.open();
    }

    public void close() {
        // some code goes here
        super.close();
        this.child.close();
        this.count = -1;
        this.isCalled = false;
    }

    public void rewind() throws DbException, TransactionAbortedException {
        // some code goes here
        this.child.rewind();
        this.count = 0;
        this.isCalled = false;
    }

    /**
     * Inserts tuples read from child into the tableId specified by the
     * constructor. It returns a one field tuple containing the number of
     * inserted records. Inserts should be passed through BufferPool. An
     * instances of BufferPool is available via Database.getBufferPool(). Note
     * that insert DOES NOT need check to see if a particular tuple is a
     * duplicate before inserting it.
     *
     * @return A 1-field tuple containing the number of inserted records, or
     *         null if called more than once.
     * @see Database#getBufferPool
     * @see BufferPool#insertTuple
     */
    protected Tuple fetchNext() throws TransactionAbortedException, DbException {
        // some code goes here
        if (isCalled) {
            return null;
        }
        isCalled = true; 
    
        BufferPool bufferPool = Database.getBufferPool();
        int insertCount = 0; 
    
        while (child.hasNext()) {
            Tuple tupleToInsert = child.next();
            try {
                bufferPool.insertTuple(tid, tableId, tupleToInsert);
                insertCount++;
            } catch (IOException e) {
                e.printStackTrace();
                break;
            }
        }
    
        this.count = insertCount;
    
        Tuple resultTuple = new Tuple(tupledesc);
        resultTuple.setField(0, new IntField(insertCount));
        return resultTuple;
    }

    @Override
    public OpIterator[] getChildren() {
        // some code goes here
        return new OpIterator[] {this.child};
    }

    @Override
    public void setChildren(OpIterator[] children) {
        // some code goes here
        this.child = children[0];
    }
}
