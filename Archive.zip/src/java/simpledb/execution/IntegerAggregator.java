package simpledb.execution;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import simpledb.common.DbException;
import simpledb.common.Type;
import simpledb.storage.Field;
import simpledb.storage.IntField;
import simpledb.storage.Tuple;
import simpledb.storage.TupleDesc;
import simpledb.transaction.TransactionAbortedException;

/**
 * Knows how to compute some aggregate over a set of IntFields.
 */
public class IntegerAggregator implements Aggregator {

    private static final long serialVersionUID = 1L;

    private int gbfield;
    private Type gbfieldtype;
    private int afield;
    private Op what;

    private Map<Field, List<Integer>> groupValues;

    /**
     * Aggregate constructor
     * 
     * @param gbfield
     *                    the 0-based index of the group-by field in the tuple, or
     *                    NO_GROUPING if there is no grouping
     * @param gbfieldtype
     *                    the type of the group by field (e.g., Type.INT_TYPE), or
     *                    null
     *                    if there is no grouping
     * @param afield
     *                    the 0-based index of the aggregate field in the tuple
     * @param what
     *                    the aggregation operator
     */

    public IntegerAggregator(int gbfield, Type gbfieldtype, int afield, Op what) {
        // some code goes here
        this.gbfield = gbfield;
        this.gbfieldtype = gbfieldtype;
        this.afield = afield;
        this.what = what;

        this.groupValues = new HashMap<>();
    }

    /**
     * Merge a new tuple into the aggregate, grouping as indicated in the
     * constructor
     * 
     * @param tup
     *            the Tuple containing an aggregate field and a group-by field
     */
    public void mergeTupleIntoGroup(Tuple tup) {
        // some code goes here
        Field groupField = gbfield == NO_GROUPING ? null : tup.getField(gbfield);
        int value = ((IntField) tup.getField(afield)).getValue();

        List<Integer> values = groupValues.getOrDefault(groupField, new ArrayList<>());
        values.add(value);
        groupValues.put(groupField, values);
    }

    /**
     * Create a OpIterator over group aggregate results.
     * 
     * @return a OpIterator whose tuples are the pair (groupVal, aggregateVal)
     *         if using group, or a single (aggregateVal) if no grouping. The
     *         aggregateVal is determined by the type of aggregate specified in
     *         the constructor.
     */
    public OpIterator iterator() {
        // some code goes here
        return new OpIterator() {
            private Iterator<Map.Entry<Field, List<Integer>>> it = groupValues.entrySet().iterator();

            @Override
            public void open() throws DbException, TransactionAbortedException {
                it = groupValues.entrySet().iterator();
            }

            @Override
            public boolean hasNext() throws DbException, TransactionAbortedException {
                return it.hasNext();
            }

            @Override
            public Tuple next() throws DbException, TransactionAbortedException, NoSuchElementException {
                Map.Entry<Field, List<Integer>> entry = it.next();
                Tuple tuple = new Tuple(getTupleDesc());
                Field groupField = entry.getKey();
                List<Integer> values = entry.getValue();
                int aggregateValue = aggregate(values);

                if (gbfield == NO_GROUPING) {
                    tuple.setField(0, new IntField(aggregateValue));
                } else {
                    tuple.setField(0, groupField);
                    tuple.setField(1, new IntField(aggregateValue));
                }
                return tuple;
            }

            private int aggregate(List<Integer> values) {
                switch (what) {
                    case MIN:
                        return Collections.min(values);
                    case MAX:
                        return Collections.max(values);
                    case SUM:
                        return values.stream().mapToInt(Integer::intValue).sum();
                    case AVG:
                        return values.stream().mapToInt(Integer::intValue).sum() / values.size();
                    case COUNT:
                        return values.size();
                    default:
                        throw new UnsupportedOperationException(
                                "IntegerAggregator: iterator()-- Unsupported operation: " + what);
                }
            }

            @Override
            public void rewind() throws DbException, TransactionAbortedException {
                open();
            }

            @Override
            public TupleDesc getTupleDesc() {
                if (gbfield == NO_GROUPING) {
                    return new TupleDesc(new Type[] { Type.INT_TYPE });
                } else {
                    return new TupleDesc(new Type[] { gbfieldtype, Type.INT_TYPE });
                }
            }

            @Override
            public void close() {
                it = null;
            }
        };
    }
}
